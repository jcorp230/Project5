﻿/* WordCount.cs
 * Created By: Juliette Corpsrein
 */


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ksu.Cis300.TextAnalyzer
{
    class WordCount
    {
        /// <summary>
        /// Stores the word
        /// </summary>
        private string _word;

        /// <summary>
        /// Stores the number of occurances of the word in each file(size is # of files)
        /// </summary>
        private int[] _counts;

        /// <summary>
        /// Property to get the word
        /// </summary>
        public string Word
        {
            get
            {
                return _word;
            }
        }

        /// <summary>
        /// Property to get the number of files beging processed
        /// </summary>
        public int NumberOfFiles
        {
            get
            {
                return _counts.Length;
            }
        }

        /// <summary>
        /// Initalize the instance of word count
        /// </summary>
        /// <param name="word">The word to store</param>
        /// <param name="size">The number of files to be processed</param>
        public WordCount(string word, int size)
        {
            _word = word;
            _counts = new int[size];
        }
            
       /// <summary>
       /// Indexer to get the number of occurances of the word in the specified file
       /// </summary>
       /// <param name="index">the file number that you want get the occurances of the word</param>
       /// <returns>returns the number of the word in the given index</returns>
       public int this[int index] {
            get
            {
                if(_counts.Length >= index)
                {
                    return _counts[index];
                }
                else
                {
                    throw new ArgumentException();
                }
            }
        }

       /// <summary>
       /// Increments the number of occurances in the word in the file location specified
       /// </summary>
       /// <param name="index">The index of the file that contains the word</param>
       public void Incremnet(int index)
        {
            if(_counts.Length >= index)
            {
                _counts[index] += 1;
            }
            else
            {
                throw new ArgumentException();
            }
        }
  
    }// end
}
