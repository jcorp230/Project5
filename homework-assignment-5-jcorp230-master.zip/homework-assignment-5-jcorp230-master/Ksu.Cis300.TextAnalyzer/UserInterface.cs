﻿/* UserInterface.cs
 * Created By: Juliette Corpsrein
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Ksu.Cis300.Sort;

namespace Ksu.Cis300.TextAnalyzer
{
    public partial class UserInterface : Form
    {
        public UserInterface()
        {
            InitializeComponent();
            uxAnalyze.Enabled = false;
        }

       /// <summary>
       /// Will keep track if the text 1 has been loaded
       /// </summary>
       bool text1 = false;

        /// <summary>
        /// keep track if the text 2 has been loaded
        /// </summary>
        bool text2 = false;

       /// <summary>
       /// Will load the first file name into the text box
       /// </summary>
       /// <param name="sender"></param>
       /// <param name="e"></param>
       private void uxText1Button_Click(object sender, EventArgs e)
        {
            if(uxOpenDialog.ShowDialog() == DialogResult.OK)
            {
                uxText1.Text = uxOpenDialog.FileName; 
            }
            text1 = true;

            if(text1 && text2)
            {
                uxAnalyze.Enabled = true;
            }
            else
            {
                uxAnalyze.Enabled = false;
            }
        }

       /// <summary>
       /// Load the second file name into the text box
       /// </summary>
       /// <param name="sender"></param>
       /// <param name="e"></param>
       private void uxText2Button_Click(object sender, EventArgs e)
        {
            if (uxOpenDialog.ShowDialog() == DialogResult.OK)
            {
                uxText2.Text = uxOpenDialog.FileName;
            }
            text2 = true;

            if (text1 && text2)
            {
                uxAnalyze.Enabled = true;
            }
            else
            {
                uxAnalyze.Enabled = false;
            }
        }

        /// <summary>
        /// Will analize the two peices of text and compute there differnce value.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uxAnalyze_Click(object sender, EventArgs e)
        {
            try
            {
                Dictionary<string, WordCount> d = new Dictionary<string, WordCount>();
                int[] words = new int[2];
                words[0] = TextAnalyzer.ProcessFile(uxText1.Text, 0, d);
                words[1] = TextAnalyzer.ProcessFile(uxText2.Text, 1, d);

                MinPriorityQueue<float, WordFrequency> mpq = TextAnalyzer.GetMostCommonWords(d, words, Convert.ToInt32(uxNumberOfWords.Value));

                float diff = TextAnalyzer.GetDifference(mpq);
                MessageBox.Show("Difference Measure: " + diff);
            }catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }//end
}
