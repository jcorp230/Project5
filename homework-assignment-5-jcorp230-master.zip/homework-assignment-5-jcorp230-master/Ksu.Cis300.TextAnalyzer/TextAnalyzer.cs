﻿/* TextAnalyzer.cs
 * Created By: Juliette Corpsrein
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Text.RegularExpressions;
using Ksu.Cis300.Sort;

namespace Ksu.Cis300.TextAnalyzer
{
    static class TextAnalyzer
    {

       /// <summary>
       /// Read and proccess the file
       /// </summary>
       /// <param name="filename">filename to process</param>
       /// <param name="numfile">the file number</param>
       /// <param name="d">number of occurances of each word in any previously processed files</param>
       /// <returns>number of words in the file</returns>
       public static int ProcessFile(string filename, int numfile, Dictionary<string, WordCount> d)
        {
            int numwords = 0;
            using (StreamReader sr = new StreamReader(filename))
            {
                while (!sr.EndOfStream)
                {
                    string line = sr.ReadLine();
                    string lower = line.ToLower();

                    string[] words = Regex.Split(lower, "[^abcdefghijklmnopqrstuvwxyz]+");

                    foreach (string w in words)
                    {
                        if (w != "")
                        {
                            WordCount value;
                            bool there = d.TryGetValue(w, out value);
                            if (!there)
                            {
                                value = new WordCount(w, 2);
                                d.Add(w, value);
                                value.Incremnet(numfile);
                                numwords++;
                            }
                            else
                            {
                                value.Incremnet(numfile);
                                numwords++;
                            }
                        }
                    }
                }
            }
            return numwords;
       }

       /// <summary>
       /// Will get the words with the highest combined freqency
       /// </summary>
       /// <param name="d">the dictonary to search throuhg</param>
       /// <param name="numWords">the number of words in each file</param>
       /// <param name="getword">the number for words you want to get</param>
       /// <returns>A min priority queue that contains the frequencis in each file of most common words</returns>
       public static MinPriorityQueue<float, WordFrequency> GetMostCommonWords(Dictionary<string, WordCount> d, int[] numWords, int getword)
        {
            MinPriorityQueue<float, WordFrequency> max = new MinPriorityQueue<float, WordFrequency>();
            foreach (string key in d.Keys)
            {
                WordCount val;
                bool there = d.TryGetValue(key, out val);
                WordFrequency freq = new WordFrequency(val, numWords);

                float freq1 = freq[0];
                float freq2 = freq[1];
                float combfreq = freq1 + freq2;
               
                max.Add(combfreq, freq);

                if(max.Count > getword)
                {
                    max.RemoveMinimumPriority();
                }
            }
            return max;
        }
    
       /// <summary>
       /// Compute the difference measure
       /// </summary>
       /// <param name="max">the min priority queue containgnig the frequencies of the words to use</param>
       /// <returns>the float value that is the differnce measure</returns>
       public static float GetDifference(MinPriorityQueue<float, WordFrequency> max)
        {
            float totalundersquare = 0;
            int i = 0;
            int count = max.Count;
            while(i < count)
            { 
                WordFrequency wf = max.RemoveMinimumPriority();
                
                float x1 = wf[0];
                float y1 = wf[1];
                float sub = x1 - y1;
                float square = sub * sub;
                totalundersquare += square;
                i++;
            }
            float root = (float)Math.Sqrt(totalundersquare);
            float end = 100 * root;
            return end;
        }


    }// end
}
