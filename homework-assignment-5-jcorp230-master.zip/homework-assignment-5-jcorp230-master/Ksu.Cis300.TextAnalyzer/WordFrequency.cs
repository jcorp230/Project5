﻿/* WordFrequency.cs
 * Created By: Juliette Corpsrein
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ksu.Cis300.TextAnalyzer
{
    struct WordFrequency
    {
       /// <summary>
       /// Stores the word
       /// </summary>
       private string _word;

       /// <summary>
       /// Stores the frequency of the word in each file
       /// </summary>
       private float[] _frequency;

       /// <summary>
       /// Set the freqencyies of the words in the word count;
       /// </summary>
       /// <param name="wc">The instance of Word Count</param>
       /// <param name="words">an array of all words</param>
       public WordFrequency(WordCount wc, int[] words)
        {
            _word = wc.Word;
            _frequency = new float[wc.NumberOfFiles];

            if(wc.NumberOfFiles != _frequency.Length)
            {
                throw new ArgumentException();
            }

            for(int i = 0; i < _frequency.Length; i++)
            {
                int count = wc[i];
                float freq = count / (float)words[i];
                _frequency[i] = freq;   
            }
        }

        /// <summary>
        /// Indexer to get the freqency of occurances of the word in the specified file
        /// </summary>
        /// <param name="index">the file number that you want get the occurances of the word</param>
        /// <returns>the float that is the frequency at the index in the array</returns>
        public float this[int index]
        {
            get
            {
                if (_frequency.Length > index)
                {
                    return _frequency[index];
                }
                else
                {
                    throw new ArgumentException();
                }
            }

        }
    }//end 
}
